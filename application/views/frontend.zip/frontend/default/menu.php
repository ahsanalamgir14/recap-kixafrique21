<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <style>
    /* Styles pour le menu principal */
    .main-nav-wrap {
      position: relative;
    }

    .mobile-overlay {
      display: none; /* Par défaut, cacher l'overlay mobile */
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      z-index: 998;
    }

    .mobile-main-nav {
      position: fixed;
      top: 0;
      left: 0;
      width: 75%;
      max-width: 300px;
      height: 100%;
      background: #fff;
      box-shadow: 2px 0 5px rgba(0, 0, 0, 0.5);
      z-index: 999;
      overflow-y: auto;
      transition: transform 0.3s ease-in-out;
      transform: translateX(-100%);
    }

    .mobile-main-nav.open {
      transform: translateX(0);
    }

    .mobile-menu-helper-top,
    .mobile-menu-helper-bottom {
      height: 50px;
    }

    .has-children > ul.category {
      display: none;
    }

    .has-children.open > ul.category {
      display: block;
    }

    /* Afficher le menu mobile */
    @media (max-width: 767.98px) {
      .mobile-overlay {
        display: block;
      }

      .mobile-main-nav {
        transform: translateX(-100%);
      }

      .mobile-main-nav.open {
        transform: translateX(0);
      }
    }

    /* Version desktop */
    @media (min-width: 768px) {
      .main-nav-wrap {
        display: flex;
        justify-content: center;
        width: 100%;
      }

      .mobile-main-nav {
        position: relative;
        transform: none;
        width: auto;
        max-width: none;
        height: auto;
        box-shadow: none;
        overflow: visible;
        display: flex;
        justify-content: center;
        margin-left: auto;
        margin-right: auto;
      }

      .mobile-main-nav.open {
        transform: none;
      }

      .has-children > ul.category {
        display: none;
        position: absolute;
        top: 100%;
        left: 0;
        background: #fff;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      }

      .has-children:hover > ul.category {
        display: block;
      }
    }
  </style>
</head>
<body>
  <button class="navbar-toggler">Menu</button>
  <div class="main-nav-wrap">
    <div class="mobile-overlay"></div>
    <ul class="mobile-main-nav">
      <div class="mobile-menu-helper-top"></div>
      <li class="text-nowrap fw-bold">
        <a href="<?php echo site_url('home/courses'); ?>"><span class="fw-500"><?php echo (' Cours'); ?></span></a>
      </li>
      <li class="has-children text-nowrap fw-bold">
        <a href="#"><span class="fw-500"><?php echo ('| Categories'); ?></span><span class="has-sub-category"><i class="fas fa-angle-right"></i></span></a>
        <ul class="category corner-triangle top-left is-hidden pb-0">
          <li class="go-back"><a href="#"><i class="fas fa-angle-left"></i><?php echo site_phrase('menu'); ?></a></li>
          <?php
          $categories = $this->crud_model->get_categories()->result_array();
          foreach ($categories as $key => $category): ?>
          <li class="has-children">
            <a href="javascript:;" class="py-2 text-wrap d-flex" onclick="redirect_to('<?php echo site_url('home/courses?category='.$category['slug']); ?>')">
              <span class="icon"><i class="<?php echo $category['font_awesome_class']; ?>"></i></span>
              <span><?php echo $category['name']; ?></span>
              <span class="has-sub-category ms-auto"><i class="fas fa-angle-right"></i></span>
            </a>
            <ul class="sub-category is-hidden">
              <li class="go-back-menu"><a href="#"><i class="fas fa-angle-left"></i><?php echo site_phrase('menu'); ?></a></li>
              <li class="go-back"><a href="#"><i class="fas fa-angle-left"></i><span class="icon"><i class="<?php echo $category['font_awesome_class']; ?>"></i></span><?php echo $category['name']; ?></a></li>
              <?php
              $sub_categories = $this->crud_model->get_sub_categories($category['id']);
              foreach ($sub_categories as $sub_category): ?>
              <li><a class="text-wrap" href="<?php echo site_url('home/courses?category='.$sub_category['slug']); ?>"><?php echo $sub_category['name']; ?></a></li>
              <?php endforeach; ?>
            </ul>
          </li>
          <?php endforeach; ?>
          <li class="all-category-devided mb-0 p-0">
            <a href="<?php echo site_url('home/courses'); ?>" class="py-3"><span class="icon"><i class="fa fa-align-justify"></i></span><span><?php echo site_phrase('all_courses'); ?></span></a>
          </li>
          <?php if(addon_status('tutor_booking')): ?>
          <li class="all-category-devided mb-0 p-0">
            <a href="<?php echo site_url('tutors'); ?>" class="py-3"><span class="icon"><i class="fas fa-chalkboard-teacher"></i></span><span><?php echo site_phrase('all_tutions'); ?></span></a>
          </li>
          <?php endif; ?>
          <?php if(addon_status('ebook')): ?>
          <li class="all-category-devided m-0 p-0">
            <a href="<?php echo site_url('ebook'); ?>" class="py-3"><span class="icon"><i class="fas fa-book"></i></span><span><?php echo site_phrase('ebooks'); ?></span></a>
          </li>
          <?php endif; ?>
          <?php if(addon_status('course_bundle')): ?>
          <li class="all-category-devided m-0 p-0">
            <a href="<?php echo site_url('course_bundles'); ?>" class="py-3"><span class="icon"><i class="fas fa-cubes"></i></span><span><?php echo site_phrase('course_bundles'); ?></span></a>
          </li>
          <?php endif; ?>
        </ul>
      </li>
      <li class="text-nowrap fw-bold">
        <a href="<?php echo site_url('home/levels'); ?>"><span class="fw-500"><?php echo ('| Niveaux'); ?></span></a>
      </li>
      <div class="mobile-menu-helper-bottom"></div>
    </ul>
  </div>

  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    document.addEventListener("DOMContentLoaded", function() {
      const mobileNav = document.querySelector(".mobile-main-nav");
      const mobileOverlay = document.querySelector(".mobile-overlay");
      const navToggleButton = document.querySelector(".navbar-toggler");
      const hasChildrenLinks = document.querySelectorAll('.has-children > a');

      navToggleButton.addEventListener("click", function() {
        mobileNav.classList.toggle("open");
        mobileOverlay.classList.toggle("open");
      });

      mobileOverlay.addEventListener("click", function() {
        mobileNav.classList.remove("open");
        mobileOverlay.classList.remove("open");
      });

      hasChildrenLinks.forEach(link => {
        link.addEventListener("click", function(e) {
          e.preventDefault();
          const parentLi = this.parentElement;
          const subMenu = parentLi.querySelector("ul");

          if (parentLi.classList.contains("open")) {
            parentLi.classList.remove("open");
            subMenu.classList.add("is-hidden");
          } else {
            parentLi.classList.add("open");
            subMenu.classList.remove("is-hidden");
          }
        });
      });
    });
  </script>
</body>
</html>
